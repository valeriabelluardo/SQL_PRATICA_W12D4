create schema ToysGroup_PraticaW12D4;

-- creato schema

create table product
(
product_id int primary key not null,
product_name varchar(50),
product_category varchar(50),
product_price double
);

insert into product (product_id, product_name,product_category,product_price) values
(01, 'Lego Creatror', 'Costruzioni',25.90),
(02,  'MagFormers', 'Costruzioni',30.99 ),
(03, 'HotWheels Pista', 'Piste',49.50),
(04, 'HotWheels Auto', 'Macchinine',8.86),
(05, 'Brio Set Treno', 'Trenini',59.99),
(06,  'Playmobil Elsa', 'Action Figure',9.99),
(07,  'Sleich Dinosauro', 'Action Figure',12.99),
(08,  'Clem Planetario', 'Scienza e Gioco',35.99),
(09,  'Ravensburger Puzzle Animali', 'Educativi',18.99),
(10, 'Hape Casa Bambole', 'Immaginazione', 65.00);

select * from product;

--  creata tabella Product

create table Sales
(
sales_id int primary key not null,
sales_date date,
region_id varchar (25),
product_id integer not null,
product_price double,
product_quantity integer,
total  double
);

insert into Sales (sales_id,sales_date,region_id,product_id,product_price,product_quantity,total)
values
(001,'2024-02-01', 1, 01, 25.90, 1500,38850),				
(002, '2024-02-02', 2, 02, 30.99, 8000,247920),				
(003, '2024-02-03', 3, 03, 49.50, 5000,247500),				
(004, '2024-02-04', 4, 04, 8.86, 5200,46072),				
(005, '2024-02-05', 5, 05, 59.99, 6000,359940),				
(006, '2024-02-06', 6, 06, 9.99, 9500,94905),				
(007, '2024-02-07', 1, 07, 12.99, 9000,116910),				
(008, '2024-02-08', 2, 08, 35.99, 2700,97173),				
(009, '2024-02-09', 3, 09, 18.99, 8100,153819),				
(010, '2023-12-10', 4, 10, 65.00, 4500,292500),				
(011, '2023-12-08', 5, 01, 25.90, 3800,98420),				
(012, '2023-12-12', 6, 02, 30.99, 1400,43386),				
(013, '2023-12-16', 6, 03, 49.50, 3000,148500),				
(014, '2023-12-07', 5, 04, 8.86, 7700,68222),				
(015, '2024-12-18', 4, 05, 59.99, 1200,71988),				
(016, '2023-12-21', 3, 06, 9.99, 2500,24975),				
(017, '2023-12-21', 2, 07, 12.99, 6300,81837),				
(018, '2023-12-22', 1, 08, 35.99, 4800,172752),				
(019, '2023-12-23', 6, 09, 18.99, 2600,49374),				
(020, '2023-12-19', 4, 10, 65.00, 1400,9100);			


select * from sales;

-- creata la tabella Sales

create table region
(
id_region smallint primary key not null,
region_name varchar(50)
);

insert into Region (id_region, region_name)
values
(1, 'Africa'),
(2, 'Asia'),
(3, 'Australia'),
(4, 'Europa'),
(5, 'Nord America'),
(6, 'Sud America');

select * from region;

-- creata tabella region

-- es. 1 Verificare che i campi definiti come PK siano univoci

select case when count(distinct sales_id) = count(sales_id)
then "unique" else "not unique" end
from sales;

select case when count(distinct id_region)= count(id_region)
then 'unique' else 'not unique' end
from region;

select case when count(distinct product_id)= count(product_id)
then 'unique' else 'not unique' end
from product;

-- sostituire nome colonna id_region con region_id

alter table region change id_region region_id int;

select * from region;

-- es. 2 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT 
	product_name,YEAR(sales_date) AS sales_year, SUM(total)
FROM
    sales
        JOIN
    product ON sales.product_id = product.product_id
GROUP BY product_name , sales_year, total
Order by sales_year, total asc;

-- es. 3 Esporre il fatturato totale per stato per anno.
-- Ordina il risultato per data e per fatturato decrescente

select 
    region_name,
    year(sales_date) as year_sales,
    sum(total) as total
from sales 
join region on sales.region_id = region.region_id
group by region.region_name, year_sales
order by year_sales, total desc;

-- es. 4 Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

select product_category, sum(product_quantity) as tot_qtà, year(sales_date) As sales_year
from product
join sales on product.product_id= sales.product_id
Group by product_category, sales_year
Order by sales_year, tot_qtà desc;

-- es. 5 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? 
-- Proponi due approcci risolutivi differenti. 

 -- 1° approccio:
 
 update sales set product_quantity= 0 where sales_id=20;
 
 select sales_id, product_id, product_quantity
from sales
where product_quantity =0;
 

-- 2° approccio

select
product.product_id,
product. product_name,
product_quantity,
sales.product_id,
sales.sales_id,
sales.sales_date
from product
left join sales on product.product_id = sales.product_id
where product_quantity = 0;


-- es. 6 Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

select distinct
	product.product_id,
    product.product_name,
    sales.sales_date
from product
left join sales on product.product_id = sales.product_id
where sales.sales_date = (
        select max(sales_date)
        from sales
        where product_id = product.product_id);
        
-- FINE







-- 








